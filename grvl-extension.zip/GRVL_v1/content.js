const WIDGET_ID = "gvl-widget";
const GEMINI_PROMPT_SELECTOR = '.ql-editor[contenteditable="true"]';
const GEMINI_SEND_BUTTON_SELECTOR = 'button[aria-label="Send message"]';
const GEMINI_GENERATING_STOP_SELECTOR = 'mat-icon[data-mat-icon-name="stop"]';
const GEMINI_MORE_OPTIONS_SELECTOR = 'button[data-test-id="more-menu-button"]';
const GEMINI_TTS_BUTTON_SELECTOR = 'button[data-test-id="tts-button"]';
const GEMINI_TTS_PAUSE_SELECTOR = 'button[aria-label="Pause"], [aria-label*="Pause"]';

let isExpanded = false;
let customTriggerPhrase = "over to you";
let customClearPhrase = "scratch that"; // Default deletion phrase
let customInterruptPhrase = "stop talking"; // Default interruption phrase

const SpeechRecognitionCtor = window.webkitSpeechRecognition;
const isSpeechRecognitionSupported = typeof SpeechRecognitionCtor === "function";

let recognition = null;
let isRecognizing = false;
let isStoppingRecognition = false;
let secondaryButtonMode = "stop";
let isSettingsOpen = false;

// Intervals & Watchdog
let generationInterval = null;
let ttsInterval = null;
let silenceRetries = 0;
const MAX_SILENCE_RETRIES = 8;

// --- WIDGET & UI HELPERS ---
function getSecondaryActionButton() { return document.querySelector(`#${WIDGET_ID} .gvl-stop`); }
function getSettingsPanel() { return document.querySelector(`#${WIDGET_ID} .gvl-settings-panel`); }

function updateSettingsInputValues() {
  const triggerInput = document.querySelector(`#${WIDGET_ID} .gvl-trigger-input`);
  const clearInput = document.querySelector(`#${WIDGET_ID} .gvl-clear-input`);
  if (triggerInput) triggerInput.value = customTriggerPhrase;
  if (clearInput) clearInput.value = customClearPhrase;
}

function setSettingsPanelState(open) {
  isSettingsOpen = open;
  const widget = document.getElementById(WIDGET_ID);
  const settingsPanel = getSettingsPanel();

  if (!widget || !settingsPanel) return;

  widget.classList.toggle("gvl-settings-open", isSettingsOpen);
  settingsPanel.setAttribute("aria-hidden", String(!isSettingsOpen));

  if (isSettingsOpen) {
    updateSettingsInputValues();
  }
}

function loadSettings() {
  if (!chrome?.storage?.sync) return;
  chrome.storage.sync.get(["gvlTriggerPhrase", "gvlClearPhrase", "gvlInterruptPhrase"], (result) => {
    if (typeof result?.gvlTriggerPhrase === "string" && result.gvlTriggerPhrase.trim()) {
      customTriggerPhrase = result.gvlTriggerPhrase.trim();
    }
    if (typeof result?.gvlClearPhrase === "string" && result.gvlClearPhrase.trim()) {
      customClearPhrase = result.gvlClearPhrase.trim();
    }
    if (typeof result?.gvlInterruptPhrase === "string" && result.gvlInterruptPhrase.trim()) {
      customInterruptPhrase = result.gvlInterruptPhrase.trim();
    }
    updateSettingsInputValues();
    console.log("[GVL] Loaded saved settings.");
  });
}

function setSecondaryButtonMode(mode) {
  const secondaryButton = getSecondaryActionButton();
  if (!secondaryButton) return;

  // Application kill-switch
  secondaryButton.textContent = "End Loop";
  secondaryButton.setAttribute("aria-label", "Disable microphone loop");
  
  // Red styling for both modes to indicate critical action
  secondaryButton.style.backgroundColor = "rgba(239, 68, 68, 0.15)"; 
  secondaryButton.style.color = "#fc9696ff"; 
  secondaryButton.style.border = "1px solid rgba(239, 68, 68, 0.2)"; 
  secondaryButton.style.borderRadius = "12px"; 
  secondaryButton.style.padding = "4px 12px";
}

// --- DOM INJECTION ---
function escapeRegExp(value) { return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

function placeCaretAtEnd(element) {
  const selection = window.getSelection();
  if (!selection) return false;
  const range = document.createRange();
  range.selectNodeContents(element);
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);
  return true;
}

function insertTextAtCursor(element, text) {
  if (!placeCaretAtEnd(element)) return false;
  try {
    const inserted = document.execCommand("insertText", false, text);
    if (inserted) return true;
  } catch (error) {}

  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return false;
  const range = selection.getRangeAt(0);
  range.deleteContents();
  const textNode = document.createTextNode(text);
  range.insertNode(textNode);
  range.setStartAfter(textNode);
  range.collapse(true);
  selection.removeAllRanges();
  selection.addRange(range);
  return true;
}

function injectTranscriptIntoPrompt(transcript) {
  const promptInput = document.querySelector(GEMINI_PROMPT_SELECTOR);
  if (!promptInput) return false;

  const existingText = promptInput.innerText || "";
  const needsLeadingSpace = existingText.trim().length > 0 && !/\s$/.test(existingText);
  const textToInsert = `${needsLeadingSpace ? " " : ""}${transcript}`;

  promptInput.focus();
  promptInput.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertText", data: textToInsert }));
  if (!insertTextAtCursor(promptInput, textToInsert)) return false;

  promptInput.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: textToInsert }));
  promptInput.dispatchEvent(new Event("change", { bubbles: true }));
  promptInput.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: " ", code: "Space" }));
  return true;
}

function clearGeminiPrompt() {
  const promptInput = document.querySelector(GEMINI_PROMPT_SELECTOR);
  if (!promptInput) return false;

  promptInput.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('delete', false, null);
  
  promptInput.dispatchEvent(new Event("input", { bubbles: true }));
  promptInput.dispatchEvent(new Event("change", { bubbles: true }));
  
  console.log("[GVL] Prompt cleared via voice command.");
  return true;
}

function transcriptHasTriggerPhrase(transcript) {
  const normalizedPhrase = customTriggerPhrase.trim().toLowerCase();
  return normalizedPhrase ? transcript.toLowerCase().includes(normalizedPhrase) : false;
}

function stripTriggerPhrase(transcript) {
  const normalizedPhrase = customTriggerPhrase.trim();
  if (!normalizedPhrase) return transcript.trim();
  const triggerRegex = new RegExp(escapeRegExp(normalizedPhrase), "gi");
  return transcript.replace(triggerRegex, "").replace(/\s+/g, " ").trim();
}

// --- THE HUMAN-SPEED RELAY & SMART DOUBLE-TAP ---

function sendGeminiPrompt() {
  const sendButton = document.querySelector(GEMINI_SEND_BUTTON_SELECTOR);
  if (sendButton && !sendButton.disabled) {
    sendButton.click();
    console.log("[GVL] Prompt sent.");
    setTimeout(startGenerationCheck, 2000);
    return true;
  }
  return false;
}

function startGenerationCheck() {
  if (generationInterval) clearInterval(generationInterval);
  console.log("[GVL] Waiting for generation to finish...");

  generationInterval = setInterval(() => {
    const stopIcon = document.querySelector(GEMINI_GENERATING_STOP_SELECTOR);
    if (!stopIcon) {
      clearInterval(generationInterval);
      generationInterval = null;
      console.log("[GVL] Generation complete.");
      setTimeout(triggerListenFlow, 200);
    }
  }, 500);
}

function triggerListenFlow() {
  const moreBtns = Array.from(document.querySelectorAll(GEMINI_MORE_OPTIONS_SELECTOR));
  const latestMoreBtn = moreBtns.reverse().find(btn => !btn.disabled && btn.isConnected && btn.getClientRects().length > 0);

  if (!latestMoreBtn) {
    console.warn("[GVL] Could not find the 3-dots menu.");
    failsafeMicStart();
    return;
  }
  
  latestMoreBtn.click();
  console.log("[GVL] Clicked 3-dots menu.");

  setTimeout(() => {
    const ttsBtns = Array.from(document.querySelectorAll(GEMINI_TTS_BUTTON_SELECTOR));
    const latestTtsBtn = ttsBtns.reverse().find(btn => !btn.disabled && btn.isConnected && btn.getClientRects().length > 0);

    if (!latestTtsBtn) {
      console.warn("[GVL] Could not find Listen button.");
      failsafeMicStart();
      return;
    }

    latestTtsBtn.click();
    console.log("[GVL] First Listen click sent. Verifying...");

    setTimeout(() => {
      const pauseBtns = Array.from(document.querySelectorAll(GEMINI_TTS_PAUSE_SELECTOR));
      const isPlaying = pauseBtns.some(btn => btn && btn.isConnected && window.getComputedStyle(btn).display !== "none");

      if (isPlaying) {
        console.log("[GVL] Audio playing successfully on first click.");
        finalizeTtsAndWatch();
      } else {
        console.log("[GVL] Click swallowed by UI. Executing second click...");
        latestMoreBtn.click();
        
        setTimeout(() => {
          const retryTtsBtns = Array.from(document.querySelectorAll(GEMINI_TTS_BUTTON_SELECTOR));
          const retryTtsBtn = retryTtsBtns.reverse().find(btn => !btn.disabled && btn.isConnected && btn.getClientRects().length > 0);
          
          if (retryTtsBtn) retryTtsBtn.click();
          console.log("[GVL] Second Listen click sent.");
          
          finalizeTtsAndWatch();
        }, 200);
      }
    }, 400);
  }, 200);
}

function finalizeTtsAndWatch() {
  setSecondaryButtonMode("restart");
  setWidgetState(true);

  startRecognition();
  
  setTimeout(() => {
    console.log("[GVL] Watching for audio to end...");
    if (ttsInterval) clearInterval(ttsInterval);
    
    ttsInterval = setInterval(() => {
      const pauseBtns = Array.from(document.querySelectorAll(GEMINI_TTS_PAUSE_SELECTOR));
      const isPlaying = pauseBtns.some(btn => btn && btn.isConnected && window.getComputedStyle(btn).display !== "none");
      
      if (!isPlaying) {
        clearInterval(ttsInterval);
        ttsInterval = null;
        console.log("[GVL] Audio finished. Restarting Mic.");
        
        setTimeout(() => {
          setWidgetState(true);
          startRecognition();
        }, 1000); 
      }
    }, 500);
  }, 3000);
}

function failsafeMicStart() {
  setWidgetState(true);
  startRecognition();
}

// --- SPEECH ENGINE ---
function createRecognition() {
  if (!isSpeechRecognitionSupported) return null;
  if (recognition) return recognition;

  recognition = new SpeechRecognitionCtor();
  recognition.continuous = true;
  recognition.interimResults = false;

  recognition.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i += 1) {
      if (!event.results[i].isFinal) continue;

      const transcript = event.results[i][0]?.transcript?.trim().toLowerCase();
      if (transcript) {
        silenceRetries = 0;
        console.log(`[GVL Captured Text]: ${transcript}`);

        // --- INTERRUPT LOGIC ---
        // If we are currently waiting for or playing audio, look ONLY for the interrupt phrase
        const isCurrentlySpeaking = document.querySelector(GEMINI_TTS_PAUSE_SELECTOR);
        if (isCurrentlySpeaking && transcript.includes(customInterruptPhrase.toLowerCase())) {
          console.log("[GVL] Interrupt phrase detected. Stopping playback.");
          isCurrentlySpeaking.click(); // Click the native pause button
          stopRecognition();
          setTimeout(() => { setWidgetState(true); startRecognition(); }, 500);
          return;
        }

        // --- NORMAL LOGIC (Only runs if not interrupted) ---
        const normalizedClear = customClearPhrase.trim().toLowerCase();
        if (normalizedClear && transcript.includes(normalizedClear)) {
          clearGeminiPrompt();
          continue; 
        }

        const shouldSend = transcriptHasTriggerPhrase(transcript);
        const finalTranscript = shouldSend ? stripTriggerPhrase(transcript) : transcript;

        if (!finalTranscript) {
          if (shouldSend) { sendGeminiPrompt(); stopRecognition(); setWidgetState(false); }
          continue;
        }

        const didInject = injectTranscriptIntoPrompt(finalTranscript);
        if (didInject && shouldSend) {
          sendGeminiPrompt();
          stopRecognition();
          setWidgetState(false);
        }
      }
    }
  };

  recognition.onerror = (event) => {
    if (event.error === "no-speech") {
       console.log("[GVL] Silence detected by browser.");
    } else if (event.error === "not-allowed" || event.error === "audio-capture") {
       setWidgetState(false);
    }
  };

  recognition.onend = () => {
    isRecognizing = false;
    
    if (isStoppingRecognition || !isExpanded) {
      isStoppingRecognition = false;
      if (isExpanded) setWidgetState(false);
      return;
    }

    if (silenceRetries < MAX_SILENCE_RETRIES) {
      silenceRetries++;
      console.log(`[GVL] Mic timeout. Watchdog restarting (${silenceRetries}/${MAX_SILENCE_RETRIES})...`);
      startRecognition();
    } else {
      console.log("[GVL] Max silence retries reached. Shutting down mic.");
      silenceRetries = 0; 
      setWidgetState(false);
    }
  };

  return recognition;
}

function startRecognition() {
  const recognitionInstance = createRecognition();
  if (!recognitionInstance) return false;
  if (isRecognizing) return true;

  try {
    recognitionInstance.start();
    isRecognizing = true;
    isStoppingRecognition = false;
    setSecondaryButtonMode("stop");
    console.log("[GVL] Mic hot.");
    return true;
  } catch (error) {
    setWidgetState(false);
    return false;
  }
}

function stopRecognition() {
  if (generationInterval) clearInterval(generationInterval);
  if (ttsInterval) clearInterval(ttsInterval);

  if (!recognition || !isRecognizing) return;
  isStoppingRecognition = true;
  setSecondaryButtonMode("stop");

  try {
    recognition.stop();
    console.log("[GVL] Mic stopped.");
  } catch (error) {
    isStoppingRecognition = false;
    isRecognizing = false;
    setWidgetState(false);
  }
}

// --- WIDGET MOUNTING ---
function setWidgetState(expanded) {
  const widget = document.getElementById(WIDGET_ID);
  if (!widget) return;

  isExpanded = expanded;
  widget.classList.toggle("gvl-expanded", isExpanded);
  widget.classList.toggle("gvl-collapsed", !isExpanded);

  const toggleButton = widget.querySelector(".gvl-toggle");
  const panel = widget.querySelector(".gvl-panel");

  if (toggleButton) {
    toggleButton.setAttribute("aria-expanded", String(isExpanded));
    toggleButton.setAttribute("aria-label", isExpanded ? "Collapse" : "Expand");
  }
  if (panel) panel.setAttribute("aria-hidden", String(!isExpanded));
  if (!isExpanded) setSettingsPanelState(false);
}

function createWidget() {
  const widget = document.createElement("div");
  widget.id = WIDGET_ID;
  widget.className = "gvl-widget gvl-collapsed";
  widget.innerHTML = `
    <div class="gvl-widget-shell">
      <button type="button" class="gvl-toggle" aria-expanded="false" style="display: flex; align-items: center; justify-content: center;">
        <span class="gvl-toggle-icon" aria-hidden="true">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18.178 8c5.096 0 5.096 8 0 8-5.096 0-7.133-8-12.356-8-5.096 0-5.096 8 0 8 5.096 0 7.133-8 12.356-8z"></path>
          </svg>
        </span>
      </button>
      <div class="gvl-panel" aria-hidden="true">
        <button type="button" class="gvl-stop">🛑 Stop</button>
        <button type="button" class="gvl-settings-toggle">⚙️</button>
      </div>
      <div class="gvl-settings-panel" aria-hidden="true">
        <div style="display: flex; flex-direction: column; gap: 12px; padding: 6px;">
          
          <!-- Trigger Phrase Setting -->
          <div>
            <label style="font-size: 12px; opacity: 0.85; font-family: inherit; margin-bottom: 4px; display: block;">Send Phrase</label>
            <input type="text" class="gvl-trigger-input" placeholder="e.g. over to you" value="${customTriggerPhrase}" style="width: 100%; padding: 4px; box-sizing: border-box;" />
          </div>

          <!-- Clear Phrase Setting -->
          <div>
            <label style="font-size: 12px; opacity: 0.85; font-family: inherit; margin-bottom: 4px; display: block;">Deletion Phrase</label>
            <input type="text" class="gvl-clear-input" placeholder="e.g. scratch that" value="${customClearPhrase}" style="width: 100%; padding: 4px; box-sizing: border-box;" />
          </div>

          <!-- NEW: Interrupt Phrase Setting -->
          <div>
            <label style="font-size: 12px; opacity: 0.85; font-family: inherit; margin-bottom: 4px; display: block;">Interrupt Phrase (TTS)</label>
            <input type="text" class="gvl-interrupt-input" placeholder="e.g. stop talking" value="${customInterruptPhrase}" style="width: 100%; padding: 4px; box-sizing: border-box;" />
          </div>

          <button type="button" class="gvl-settings-save" style="margin-top: 4px;">Save Settings</button>
        </div>
      </div>
    </div>
  `;

  widget.querySelector(".gvl-toggle")?.addEventListener("click", () => {
    if (isExpanded) { stopRecognition(); setWidgetState(false); return; }
    setWidgetState(true);
    if (!startRecognition()) setWidgetState(false);
  });

  widget.querySelector(".gvl-stop")?.addEventListener("click", () => {
    if (secondaryButtonMode === "restart") {
      setWidgetState(true);
      if (!startRecognition()) setWidgetState(false);
      return;
    }
    stopRecognition();
    setWidgetState(false);
  });

  widget.querySelector(".gvl-settings-toggle")?.addEventListener("click", () => setSettingsPanelState(!isSettingsOpen));

  widget.querySelector(".gvl-settings-save")?.addEventListener("click", () => {
    const triggerInput = widget.querySelector(".gvl-trigger-input");
    const clearInput = widget.querySelector(".gvl-clear-input");
    const interruptInput = widget.querySelector(".gvl-interrupt-input"); // Grab 3rd input
    
    customTriggerPhrase = triggerInput?.value?.trim() || "over to you";
    customClearPhrase = clearInput?.value?.trim() || "scratch that";
    customInterruptPhrase = interruptInput?.value?.trim() || "stop talking"; // Save 3rd variable
    
    if (triggerInput) triggerInput.value = customTriggerPhrase;
    if (clearInput) clearInput.value = customClearPhrase;
    if (interruptInput) interruptInput.value = customInterruptPhrase;
    
    if (chrome?.storage?.sync) {
      chrome.storage.sync.set({ 
        gvlTriggerPhrase: customTriggerPhrase,
        gvlClearPhrase: customClearPhrase,
        gvlInterruptPhrase: customInterruptPhrase // Push to storage
      }, () => {
        const btn = widget.querySelector(".gvl-settings-save");
        btn.textContent = "Saved!";
        window.setTimeout(() => { btn.textContent = "Save Settings"; }, 1200);
      });
    }
  });

  setSecondaryButtonMode("stop");
  return widget;
}

function mountWidget() {
  let widget = document.getElementById(WIDGET_ID);
  if (!widget) widget = createWidget();
  if (document.body && widget.parentElement !== document.body) document.body.appendChild(widget);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountWidget, { once: true });
} else {
  mountWidget();
}
loadSettings();